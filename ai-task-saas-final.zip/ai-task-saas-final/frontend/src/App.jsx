import React, {useEffect, useState} from 'react';
import {createRoot} from 'react-dom/client';
import {DndContext, closestCenter, useDroppable, useDraggable} from '@dnd-kit/core';
import {CSS} from '@dnd-kit/utilities';
import './style.css';

const API = import.meta.env.VITE_API_URL || 'http://localhost:5000';
const tokenHeader = () => ({ Authorization: 'Bearer ' + localStorage.getItem('token'), 'Content-Type':'application/json' });

function App(){
  const [token,setToken] = useState(localStorage.getItem('token') || '');
  return token ? <Dashboard onLogout={()=>{localStorage.removeItem('token');setToken('')}}/> : <Auth onToken={(t)=>{localStorage.setItem('token',t);setToken(t)}}/>;
}

function Auth({onToken}){
  const [email,setEmail]=useState('demo@example.com');
  const [password,setPassword]=useState('password123');
  const [msg,setMsg]=useState('');
  async function submit(mode){
    setMsg('');
    const res=await fetch(`${API}/api/auth/${mode}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password})});
    const data=await res.json();
    if(data.token) onToken(data.token); else setMsg(data.error||'خطأ');
  }
  return <main className="auth"><section className="panel"><h1>منصة إدارة المهام بالذكاء الاصطناعي</h1><input value={email} onChange={e=>setEmail(e.target.value)} placeholder="البريد"/><input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="كلمة المرور"/><div className="row"><button onClick={()=>submit('login')}>دخول</button><button className="secondary" onClick={()=>submit('register')}>تسجيل</button></div>{msg && <p className="err">{msg}</p>}</section></main>
}

function Dashboard({onLogout}){
  const [tasks,setTasks]=useState([]);
  const [manual,setManual]=useState('');
  const [aiText,setAiText]=useState('');
  const [chat,setChat]=useState('خطط يومي');
  const [answer,setAnswer]=useState('');
  const [schedule,setSchedule]=useState([]);

  async function load(){ const r=await fetch(`${API}/api/tasks`,{headers:tokenHeader()}); if(r.ok) setTasks(await r.json()); }
  useEffect(()=>{load()},[]);
  async function createTask(task){ const r=await fetch(`${API}/api/tasks`,{method:'POST',headers:tokenHeader(),body:JSON.stringify(task)}); if(r.ok) setTasks([await r.json(),...tasks]); }
  async function updateTask(id, patch){ const r=await fetch(`${API}/api/tasks/${id}`,{method:'PUT',headers:tokenHeader(),body:JSON.stringify(patch)}); if(r.ok) setTasks(tasks.map(t=>t.id===id?{...t,...patch}:t)); }
  async function addManual(){ if(!manual.trim()) return; await createTask({title:manual,priority:'medium',status:'todo'}); setManual(''); }
  async function addAI(){ if(!aiText.trim()) return; const r=await fetch(`${API}/api/ai/analyze`,{method:'POST',headers:tokenHeader(),body:JSON.stringify({text:aiText})}); const data=await r.json(); await createTask(data); setAiText(''); }
  async function askAI(){ const r=await fetch(`${API}/api/ai/agent`,{method:'POST',headers:tokenHeader(),body:JSON.stringify({question:chat})}); const data=await r.json(); setAnswer(data.result||''); }
  async function notify(){ const r=await fetch(`${API}/api/notifications/check`,{method:'POST',headers:tokenHeader()}); const data=await r.json(); alert(data.message); }
  function planDay(){ const ordered=[...tasks].filter(t=>t.status!=='done').sort((a,b)=>score(b)-score(a)).slice(0,5); let hour=8; setSchedule(ordered.map(t=>`${String(hour++).padStart(2,'0')}:00 - ${t.title}`)); }
  function score(t){ return t.priority==='high'?3:t.priority==='medium'?2:1; }
  function exportCSV(){ const rows=tasks.map(t=>`"${t.title.replaceAll('"','""')}",${t.priority},${t.status},${t.due_date||''}`); const blob=new Blob(['المهمة,الأولوية,الحالة,الموعد\n'+rows.join('\n')],{type:'text/csv;charset=utf-8'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='tasks.csv'; a.click(); }
  function onDragEnd(e){ if(!e.over) return; updateTask(e.active.id,{status:e.over.id}); }
  const total=tasks.length, done=tasks.filter(t=>t.status==='done').length, prod=total?Math.round(done/total*100):0;
  return <main className="app" dir="rtl"><header><h1>🚀 منصة إدارة المهام الذكية</h1><button className="secondary" onClick={onLogout}>خروج</button></header>
    <section className="grid cards"><Card title="المهام" value={total}/><Card title="منجزة" value={done}/><Card title="الإنتاجية" value={prod+'%'}/></section>
    <section className="panel"><div className="row"><input value={manual} onChange={e=>setManual(e.target.value)} placeholder="إضافة مهمة يدوية"/><button onClick={addManual}>إضافة</button></div><div className="row"><input value={aiText} onChange={e=>setAiText(e.target.value)} placeholder="اكتب طلب المهمة وسيحلله AI"/><button className="purple" onClick={addAI}>إضافة بالذكاء</button></div><div className="row"><button onClick={planDay}>📅 Time Blocking</button><button onClick={notify} className="danger">🔔 فحص الضغط</button><button onClick={exportCSV} className="green">تصدير Excel CSV</button></div></section>
    {schedule.length>0 && <section className="panel"><h2>جدول اليوم</h2>{schedule.map((x,i)=><p key={i}>{x}</p>)}</section>}
    <DndContext collisionDetection={closestCenter} onDragEnd={onDragEnd}><section className="kanban"><Column id="todo" title="للعمل" tasks={tasks.filter(t=>t.status==='todo')}/><Column id="progress" title="قيد التنفيذ" tasks={tasks.filter(t=>t.status==='progress')}/><Column id="done" title="منجز" tasks={tasks.filter(t=>t.status==='done')}/></section></DndContext>
    <section className="panel"><h2>🤖 المساعد الذكي</h2><textarea value={chat} onChange={e=>setChat(e.target.value)} /><button onClick={askAI}>اسأل AI</button>{answer && <pre>{answer}</pre>}</section>
  </main>
}
function Card({title,value}){return <div className="card"><span>{title}</span><b>{value}</b></div>}
function Column({id,title,tasks}){const {setNodeRef}=useDroppable({id}); return <div ref={setNodeRef} className="col"><h3>{title}</h3>{tasks.map(t=><Task key={t.id} task={t}/>)}</div>}
function Task({task}){const {attributes,listeners,setNodeRef,transform}=useDraggable({id:task.id}); const color=task.priority==='high'?'red':task.priority==='medium'?'yellow':'green'; return <div ref={setNodeRef} {...listeners} {...attributes} style={{transform:CSS.Transform.toString(transform)}} className="task"><span>{task.title}</span><em className={color}>{task.priority}</em></div>}

createRoot(document.getElementById('root')).render(<App/>);
