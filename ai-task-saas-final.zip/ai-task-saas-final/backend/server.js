const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const OpenAI = require('openai');
const TelegramBot = require('node-telegram-bot-api');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret_change_me';
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;
const telegramBot = process.env.TELEGRAM_BOT_TOKEN ? new TelegramBot(process.env.TELEGRAM_BOT_TOKEN, { polling: false }) : null;

app.use(helmet());
app.use(cors({ origin: true }));
app.use(express.json({ limit: '1mb' }));

function sign(user){ return jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '8h' }); }
function auth(req,res,next){
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : header;
  if(!token) return res.status(401).json({error:'NO_TOKEN'});
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch(e){ return res.status(401).json({error:'INVALID_TOKEN'}); }
}

app.get('/health', (req,res)=>res.json({ok:true, service:'ai-task-saas'}));

app.post('/api/auth/register', async (req,res)=>{
  const { email, password } = req.body || {};
  if(!email || !password || password.length < 6) return res.status(400).json({error:'EMAIL_AND_PASSWORD_REQUIRED'});
  const hash = await bcrypt.hash(password, 10);
  try{
    const r = await pool.query('INSERT INTO users(email,password_hash) VALUES($1,$2) RETURNING id,email,role', [email.toLowerCase(), hash]);
    res.json({ token: sign(r.rows[0]), user: r.rows[0] });
  }catch(e){
    if(String(e.message).includes('duplicate')) return res.status(409).json({error:'EMAIL_EXISTS'});
    res.status(500).json({error:'REGISTER_FAILED'});
  }
});

app.post('/api/auth/login', async (req,res)=>{
  const { email, password } = req.body || {};
  const r = await pool.query('SELECT id,email,password_hash,role FROM users WHERE email=$1', [String(email||'').toLowerCase()]);
  const user = r.rows[0];
  if(!user) return res.status(401).json({error:'INVALID_LOGIN'});
  const ok = await bcrypt.compare(password || '', user.password_hash);
  if(!ok) return res.status(401).json({error:'INVALID_LOGIN'});
  res.json({ token: sign(user), user: {id:user.id,email:user.email,role:user.role} });
});

app.get('/api/tasks', auth, async (req,res)=>{
  const r = await pool.query('SELECT id,title,description,source,priority,status,due_date,created_at,updated_at FROM tasks WHERE user_id=$1 ORDER BY created_at DESC', [req.user.id]);
  res.json(r.rows);
});

app.post('/api/tasks', auth, async (req,res)=>{
  const t = req.body || {};
  if(!t.title) return res.status(400).json({error:'TITLE_REQUIRED'});
  const r = await pool.query(`INSERT INTO tasks(user_id,title,description,source,priority,status,due_date)
    VALUES($1,$2,$3,$4,$5,$6,$7)
    RETURNING id,title,description,source,priority,status,due_date,created_at,updated_at`,
    [req.user.id, t.title, t.description||'', t.source||'', t.priority||'medium', t.status||'todo', t.due_date||null]);
  res.json(r.rows[0]);
});

app.put('/api/tasks/:id', auth, async (req,res)=>{
  const t = req.body || {};
  const r = await pool.query(`UPDATE tasks SET title=COALESCE($1,title), description=COALESCE($2,description), source=COALESCE($3,source), priority=COALESCE($4,priority), status=COALESCE($5,status), due_date=$6, updated_at=NOW()
    WHERE id=$7 AND user_id=$8 RETURNING id,title,description,source,priority,status,due_date,created_at,updated_at`,
    [t.title, t.description, t.source, t.priority, t.status, t.due_date || null, req.params.id, req.user.id]);
  if(!r.rows[0]) return res.status(404).json({error:'NOT_FOUND'});
  res.json(r.rows[0]);
});

app.delete('/api/tasks/:id', auth, async (req,res)=>{
  await pool.query('DELETE FROM tasks WHERE id=$1 AND user_id=$2', [req.params.id, req.user.id]);
  res.json({ok:true});
});

function heuristicAnalyze(text){
  const s = String(text||'');
  const priority = /(عاجل|فور|اليوم|خلال يوم|طارئ|urgent)/i.test(s) ? 'high' : /(تقرير|مهم|خلال 3|خلال ثلاثة|عرض)/i.test(s) ? 'medium' : 'low';
  return { title:s.trim(), priority, status:'todo', description:'', source:'' };
}

app.post('/api/ai/analyze', auth, async (req,res)=>{
  const { text } = req.body || {};
  if(!text) return res.status(400).json({error:'TEXT_REQUIRED'});
  if(!openai) return res.json(heuristicAnalyze(text));
  try{
    const response = await openai.responses.create({
      model: 'gpt-4o-mini',
      instructions: 'استخرج مهمة إدارية من النص وأعد JSON فقط بالمفاتيح: title, priority(high|medium|low), description, source, due_date بصيغة YYYY-MM-DD أو null.',
      input: text
    });
    const raw = response.output_text || '{}';
    const cleaned = raw.replace(/```json|```/g,'').trim();
    const parsed = JSON.parse(cleaned);
    res.json({ ...heuristicAnalyze(text), ...parsed, status:'todo' });
  }catch(e){ res.json(heuristicAnalyze(text)); }
});

app.post('/api/ai/agent', auth, async (req,res)=>{
  const { question } = req.body || {};
  const tasks = (await pool.query('SELECT title,priority,status,due_date FROM tasks WHERE user_id=$1', [req.user.id])).rows;
  if(!openai){
    const high = tasks.filter(t=>t.priority==='high').map(t=>'- '+t.title).join('\n') || 'لا توجد مهام عالية.';
    return res.json({result:`تحليل سريع:\n${high}\nابدأ بالمهام العالية ثم المتوسطة.`});
  }
  const response = await openai.responses.create({
    model:'gpt-4o-mini',
    instructions:'أنت مساعد إداري عربي. حلل المهام وقدّم أولويات وخطة يومية مختصرة وعملية.',
    input:`المهام: ${JSON.stringify(tasks)}\nالسؤال: ${question||'خطط يومي'}`
  });
  res.json({result: response.output_text});
});

app.post('/api/notifications/check', auth, async (req,res)=>{
  const r = await pool.query("SELECT count(*)::int AS c FROM tasks WHERE user_id=$1 AND priority='high' AND status <> 'done'", [req.user.id]);
  const count = r.rows[0].c;
  const message = count > 3 ? '🚨 ضغط عمل مرتفع: لديك مهام عاجلة كثيرة.' : count > 0 ? '⚠️ لديك مهام عاجلة تحتاج متابعة.' : '✅ جدولك مستقر.';
  let sent = false;
  if (telegramBot && process.env.TELEGRAM_CHAT_ID && count > 0) {
    try { await telegramBot.sendMessage(process.env.TELEGRAM_CHAT_ID, message); sent = true; } catch(e) { sent = false; }
  }
  res.json({message, count, telegramSent: sent});
});

app.listen(PORT, ()=>console.log(`API running on ${PORT}`));
