# AI Task SaaS Final

نسخة نهائية قابلة للتشغيل محليًا والنشر عبر Docker.

## التشغيل السريع
1. انسخ `.env.example` إلى `backend/.env` وعدّل القيم.
2. شغّل:
```bash
docker compose up --build
```
3. افتح الواجهة: http://localhost:3000
4. الـ API: http://localhost:5000/health

## المزايا
- تسجيل/دخول JWT.
- مهام محفوظة في PostgreSQL.
- Kanban Drag & Drop.
- AI لإضافة مهمة من نص.
- AI Chat لتخطيط اليوم وتحليل الضغط.
- Time Blocking.
- استيراد/تصدير CSV متوافق مع Excel.
- إشعارات Telegram اختيارية.

## ملاحظات أمنية
- لا تضع OPENAI_API_KEY في الواجهة.
- استخدم HTTPS في النشر الحقيقي.
- غيّر JWT_SECRET.
